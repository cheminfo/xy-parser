import type { DataXY, TextData } from 'cheminfo-types';
import type { ParseXYOptions } from './ParseXYOptions.ts';
/**
 * General internal parsing function
 * @param text - Csv or tsv strings.
 * @param options - Parsing options
 * @returns parsed text file with column information
 */
export declare function parse(text: TextData, options?: ParseXYOptions): {
    info: Array<{
        position: number;
        value: string;
    }>;
    data: DataXY;
};
//# sourceMappingURL=parse.d.ts.map