import type { TextData } from 'cheminfo-types';
import type { ParseXYOptions } from './ParseXYOptions.ts';
export * from './ParseXYOptions.ts';
/**
 * Parse a text-file and convert it to an object {x:[], y:[]}
 * @param text - Csv or tsv strings.
 * @param options - Parsing options
 * @returns - The parsed data
 */
export declare function parseXY(text: TextData, options?: ParseXYOptions): import("cheminfo-types").DataXY<import("cheminfo-types").NumberArray>;
/**
 * Parse a text-file and returns the parsed data and information about the columns
 * @param text - Csv or tsv strings.
 * @param options - Parsing options
 * @returns - The parsed data with information about the columns
 */
export declare function parseXYAndKeepInfo(text: TextData, options?: ParseXYOptions): {
    info: Array<{
        position: number;
        value: string;
    }>;
    data: import("cheminfo-types").DataXY;
};
//# sourceMappingURL=index.d.ts.map